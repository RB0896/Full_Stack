package com.demo.bankapp;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

import com.demo.bankapp.models.Account;
import com.demo.bankapp.models.Transaction;

public class BankApp {

	public static void main(String[] args) {

		int accountNo;
		String accountHolderName;
		float accountBalance;
		String accountBranch;
		long contact;
		Account accountDetails;
		int transId=1000;
		

		HashMap<Integer, Account> accounts = new HashMap<Integer, Account>();
		HashMap<Integer,Transaction> trans = new HashMap<Integer,Transaction>();
		Scanner scan = new Scanner(System.in);
		while (true) {
			System.out.println("*********Bullet Bank*********");
			System.out.println("1)Create Account");
			System.out.println("2)View Account Details");
			System.out.println("3)Withdrawl");
			System.out.println("4)Deposit");
			System.out.println("5)Transfer your money");
			System.out.println("6)Print Transactions");
			System.out.println("7)Exit");
			int option = scan.nextInt();
			switch (option) {
			case 1:
				System.out.println("Enter Details to create Account: ");
				System.out.println("Enter your Full Name : ");
				accountHolderName = scan.next();
				System.out.println("Enter Branch : ");
				accountBranch = scan.next();
				System.out.println("Enter amount to deposit in the account : ");
				int amount = scan.nextInt();
				accountBalance = amount;
				System.out.println("Enter your Contact Number : ");
				contact = scan.nextLong();
				accountNo = (int) (contact - 9999);
				Account account = new Account(accountNo, accountHolderName, accountBalance, accountBranch, contact);
				accounts.put(accountNo, account);
				System.out.println("Account created Successfully");
				System.out.println("Your account number is " + accountNo);

				break;
			case 2:
				System.out.println("Enter Account Number : ");
				accountNo = scan.nextInt();
				accountDetails = accounts.get(accountNo);
				Transaction transactionDetails = new Transaction(++transId, "View", 0, accountNo, 0, new Date());
				Transaction transaction = trans.put(transId, transactionDetails);
				System.out.println(accountDetails);

				break;
			case 3:
				System.out.println("Enter your Account No");
				accountNo = scan.nextInt();
				accountDetails = accounts.get(accountNo);
				System.out.println("Enter amount to withdrawl : ");
				float amountToWithdrawl = scan.nextFloat();
				float updatedBalance = (int) (accountDetails.getAccountBalance() - amountToWithdrawl);
				accountDetails.setAccountBalance(updatedBalance);
				Transaction transactionDetails1 = new Transaction(++transId, "Withdraw", updatedBalance, accountNo, 0, new Date());
				Transaction transaction1 = trans.put(transId, transactionDetails1);
				System.out
						.println("Your amount has be successfully withdrawn,your updated balance is " + updatedBalance);
				break;
			case 4:
				System.out.println("Enter your account number: ");
				accountNo = scan.nextInt();
				accountDetails = accounts.get(accountNo);
				System.out.println("Enter amount yo deposit ");
				int amountToDeposit = scan.nextInt();
				updatedBalance = (int) (accountDetails.getAccountBalance() + amountToDeposit);
				accountDetails.setAccountBalance(updatedBalance);
				Transaction transactionDetails2 = new Transaction(++transId, "Deposit", updatedBalance, accountNo, 0, new Date());
				Transaction transaction2 = trans.put(transId, transactionDetails2);
				System.out.println(
						"Your amount has been successfully deposited ,your updated balance is " + updatedBalance);

				break;
			case 5:
				System.out.println("Enter from account number");
				int fromaccountNo = scan.nextInt();
				Account fromAccountDetails = accounts.get(fromaccountNo);
				System.out.println("Enter To accountNo");
				int toAccountNo = scan.nextInt();
				Account toAccountDetails = accounts.get(toAccountNo);
				System.out.println("Enter amount to transfer");
				int amountToTransfer = scan.nextInt();

				float updatedFromAccountBalance = (int) (fromAccountDetails.getAccountBalance() - amountToTransfer);
				fromAccountDetails.setAccountBalance(updatedFromAccountBalance);
				accounts.put(fromaccountNo, fromAccountDetails);
				float updatedToAccountBalance = (int) (toAccountDetails.getAccountBalance() + amountToTransfer);
				toAccountDetails.setAccountBalance(updatedToAccountBalance);
				accounts.put(toAccountNo, toAccountDetails);
				Transaction transactionDetails3 = new Transaction(++transId, "transfer", updatedFromAccountBalance, fromaccountNo, toAccountNo, new Date());
				Transaction transaction3 = trans.put(transId, transactionDetails3);
				System.out.println("Amount has been transffered from " + fromaccountNo + " to " + toAccountNo);

				break;
			case 6:
				Set<Integer> set = trans.keySet();
				Iterator itr= set.iterator();
				while(itr.hasNext())
				{
					int transIds=(int) itr.next();
					System.out.println(trans.get(transIds));
					
				}

				
				
				

				break;
			case 7:
				System.out.println("Thank you");
				scan.close();
				System.exit(option);

				break;

			}
		}
	}
}
