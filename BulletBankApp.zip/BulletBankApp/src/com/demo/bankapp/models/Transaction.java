package com.demo.bankapp.models;

import java.util.Date;

public class Transaction {
	private int transactionId;
	private String transactionType;
	private float balance;
	private int fromAccount;
	private int toAccount;
	private Date dateOfTransaction;

	public Transaction() {
		super();
	}

	public Transaction(int transactionId, String transactionType, float balance, int fromAccount, int toAccount,
			Date dateOfTransaction) {
		super();
		this.transactionId = transactionId;
		this.transactionType = transactionType;
		this.balance = balance;
		this.fromAccount = fromAccount;
		this.toAccount = toAccount;
		this.dateOfTransaction = dateOfTransaction;
	}

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public float getBalance() {
		return balance;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}

	public int getFromAccount() {
		return fromAccount;
	}

	public void setFromAccount(int fromAccount) {
		this.fromAccount = fromAccount;
	}

	public int getToAccount() {
		return toAccount;
	}

	public void setToAccount(int toAccount) {
		this.toAccount = toAccount;
	}

	public Date getDateOfTransaction() {
		return dateOfTransaction;
	}

	public void setDateOfTransaction(Date dateOfTransaction) {
		this.dateOfTransaction = dateOfTransaction;
	}

	@Override
	public String toString() {
		return " [transactionId=" + transactionId + ", transactionType=" + transactionType + ", balance="
				+ balance + ", fromAccount=" + fromAccount + ", toAccount=" + toAccount + ", dateOfTransaction="
				+ dateOfTransaction + "]";
	}

}
